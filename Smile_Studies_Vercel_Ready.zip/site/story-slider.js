(function(){
  let timer=null;
  window.initStorySlider=function(){
    clearTimeout(timer);
    const slider=document.getElementById('storySlider'); if(!slider)return;
    const slides=[...slider.querySelectorAll('.story-slide')];
    const dots=[...slider.querySelectorAll('.story-dot')];
    const progress=slider.querySelector('.story-progress');
    const prev=slider.querySelector('.story-prev');
    const next=slider.querySelector('.story-next');
    if(!slides.length)return;
    let current=Math.max(0,slides.findIndex(s=>s.classList.contains('active')));
    function restart(){
      clearTimeout(timer);
      if(progress){progress.style.transition='none';progress.style.width='0%';requestAnimationFrame(()=>requestAnimationFrame(()=>{progress.style.transition='width 4.2s linear';progress.style.width='100%'}));}
      timer=setTimeout(()=>show(current+1),4200);
    }
    function show(i){current=(i+slides.length)%slides.length;slides.forEach((s,x)=>s.classList.toggle('active',x===current));dots.forEach((d,x)=>d.classList.toggle('active',x===current));restart();}
    if(prev)prev.onclick=()=>show(current-1);
    if(next)next.onclick=()=>show(current+1);
    dots.forEach((d,i)=>d.onclick=()=>show(i));
    slider.onmouseenter=()=>{clearTimeout(timer);if(progress)progress.style.transition='none'};
    slider.onmouseleave=restart;
    let x0=null;
    slider.ontouchstart=e=>x0=e.touches[0].clientX;
    slider.ontouchend=e=>{if(x0===null)return;const dx=e.changedTouches[0].clientX-x0;if(Math.abs(dx)>45)show(current+(dx<0?1:-1));else restart();x0=null};
    restart();
  };
  document.addEventListener('DOMContentLoaded',()=>window.initStorySlider());
})();
