// Smile Studies Firebase web configuration.
// Core login/signup currently uses the CMS server + Firebase Authentication REST API.
window.SMILE_FIREBASE_CONFIG = {
  apiKey: "AIzaSyA_PqbAmxLz8t6K4KrOaydStrHrodLtTzs",
  authDomain: "smile-studies.firebaseapp.com",
  projectId: "smile-studies",
  storageBucket: "smile-studies.firebasestorage.app",
  messagingSenderId: "489989391819",
  appId: "1:489989391819:web:84a51e976dc223197fa24e"
};
