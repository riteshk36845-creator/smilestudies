window.SMILE_CLOUD_CONFIG = {
  adminEmail: "kritesh2663@gmail.com",
  firebaseProjectId: "smile-studies",
  cloudMode: true
};
