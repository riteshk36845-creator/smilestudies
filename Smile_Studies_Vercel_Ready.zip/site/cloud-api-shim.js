(()=>{
'use strict';
const realFetch=window.fetch.bind(window);
const jsonResponse=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json'}});
const cfg=window.SMILE_FIREBASE_CONFIG||{};
const cloudCfg=window.SMILE_CLOUD_CONFIG||{};
let app,auth,db,mods,currentUser=null;
const ready=(async()=>{
  const [appMod,authMod,fsMod]=await Promise.all([
    import('https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js'),
    import('https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js'),
    import('https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js')
  ]);
  mods={...appMod,...authMod,...fsMod};
  app=appMod.initializeApp(cfg);
  auth=authMod.getAuth(app);
  db=fsMod.getFirestore(app);
  await new Promise(res=>authMod.onAuthStateChanged(auth,u=>{currentUser=u;res();}));
})();
const now=()=>new Date().toISOString();
const numId=()=>Date.now()*100+Math.floor(Math.random()*90+10);
const normMobile=s=>String(s||'').replace(/\D/g,'');
async function sha256(s){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(String(s)));return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}
async function token(){await ready;return currentUser?await currentUser.getIdToken():''}
function admin(){return currentUser&&String(currentUser.email||'').toLowerCase()===String(cloudCfg.adminEmail||'').toLowerCase()}
function requireAdmin(){if(!admin())throw Object.assign(new Error('Admin login required'),{status:401});}
function parseBody(init){try{return JSON.parse(init?.body||'{}')}catch{return {}}}
function docData(snap){return snap.exists()?snap.data():null}
async function freshDoc(ref){try{return await mods.getDocFromServer(ref)}catch{return await mods.getDoc(ref)}}
async function freshDocs(ref){try{return await mods.getDocsFromServer(ref)}catch{return await mods.getDocs(ref)}}
async function allContent(){await ready;const s=await freshDocs(mods.collection(db,'content'));return s.docs.map(d=>({...d.data(),id:(d.data().id ?? (Number(d.id)||d.id)),_docId:d.id}));}
async function allCatalog(){await ready;const s=await freshDocs(mods.collection(db,'catalog'));return s.docs.map(d=>({...d.data(),id:(d.data().id ?? (Number(d.id)||d.id)),_docId:d.id}));}
function catalogOf(o){const m=o.meta||{},atts=Array.isArray(m.attachments)?m.attachments.map((a,i)=>({name:a?.name||`File ${i+1}`,url:String(a?.url||'').startsWith('b2:')?'b2:protected':(a?.url||'')})):[];return {id:o.id,type:o.type||'',title:o.title||'',subtitle:o.subtitle||'',description:o.description||'',media_url:String(o.media_url||'').startsWith('b2:')?'b2:protected':(o.media_url||''),file_url:String(o.file_url||'').startsWith('b2:')?'b2:protected':(o.file_url||''),link_url:(m.access||'public')==='public'?(o.link_url||''):'',category:o.category||'others',status:o.status||'draft',sort_order:Number(o.sort_order||0),meta:{section:m.section||'',mode:m.mode||'',access:m.access||'public',price:m.price||'',duration_minutes:Number(m.duration_minutes||0),attachments:atts},updated_at:o.updated_at||now()}}
async function syncCatalog(o){await mods.setDoc(mods.doc(db,'catalog',String(o.id)),catalogOf(o),{merge:false})}
async function allCategories(){await ready;const s=await freshDocs(mods.collection(db,'categories'));return s.docs.map(d=>({...d.data(),id:(d.data().id ?? (Number(d.id)||d.id)),_docId:d.id})).sort((a,b)=>(a.sort_order||0)-(b.sort_order||0));}
async function seedCategories(){let x=await allCategories();if(x.length||!admin())return x;const defs=[['indian-air-force','Indian Air Force'],['indian-navy','Indian Navy'],['indian-army','Indian Army'],['ssc-gd-constable','SSC GD Constable'],['others','Others']];for(let i=0;i<defs.length;i++){const id=numId()+i;await mods.setDoc(mods.doc(db,'categories',String(id)),{id,slug:defs[i][0],name:defs[i][1],sort_order:i+1,status:'published',created_at:now(),updated_at:now()})}return allCategories()}
async function settings(){await ready;return docData(await freshDoc(mods.doc(db,'settings','site')))||{};}
async function signedRef(item,field='file_url',mode='view'){
  const ref=item?.[field]; if(!String(ref||'').startsWith('b2:'))return ref||'';
  const t=await token();
  const r=await realFetch(`/api/b2-file?id=${encodeURIComponent(item.id)}&field=${field==='media_url'?'media':'file'}&mode=${mode}`,{headers:t?{Authorization:`Bearer ${t}`}:{}});
  const d=await r.json().catch(()=>({})); return r.ok?d.url:'';
}
async function signedSetting(field){const s=await settings();if(!String(s[field]||'').startsWith('b2:'))return s[field]||'';const r=await realFetch(`/api/b2-file?settingsField=${encodeURIComponent(field)}&mode=view`);const d=await r.json().catch(()=>({}));return r.ok?d.url:''}
async function hasAccess(item){if((item.meta?.access||'public')==='public')return true;if(!currentUser)return false;const s=await mods.getDoc(mods.doc(db,'users',currentUser.uid,'library',String(item.id)));return s.exists()}
async function decorate(item){const x=structuredClone(item);x.has_access=await hasAccess(x);if(x.media_url&&x.has_access)x.media_url=await signedRef(x,'media_url','view');return x}
async function profile(){if(!currentUser)return null;return docData(await mods.getDoc(mods.doc(db,'users',currentUser.uid)));}
async function findUserByNumeric(id){const s=await mods.getDocs(mods.collection(db,'users'));for(const d of s.docs){if(String(d.data().id)===String(id))return {uid:d.id,...d.data()}}return null}
async function userLibrary(uid){const s=await mods.getDocs(mods.collection(db,'users',uid,'library'));const out=[];for(const ld of s.docs){const cs=await mods.getDoc(mods.doc(db,'content',String(ld.id)));if(cs.exists()&&cs.data().status==='published')out.push({...cs.data(),library_added_at:ld.data()?.added_at||''})}return out}
async function uploadBase64(body){
  requireAdmin();
  const name=String(body.name||'file').replace(/[\r\n]/g,'');
  const mime=body.mime||'application/octet-stream';
  const raw=atob(body.data_base64||'');
  const bytes=new Uint8Array(raw.length);
  for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
  if(!bytes.length)throw Error('Selected file is empty');

  const hash=await crypto.subtle.digest('SHA-1',bytes);
  const sha1=[...new Uint8Array(hash)].map(x=>x.toString(16).padStart(2,'0')).join('');
  const safe=name.replace(/[^A-Za-z0-9._() -]/g,'_');
  const key=`uploads/${new Date().toISOString().slice(0,10)}/${Date.now()}-${crypto.randomUUID()}-${safe}`;
  const t=await token();

  async function getTicket(){
    let ticketR;
    try{
      ticketR=await realFetch('/api/b2-upload-ticket',{method:'POST',headers:{Authorization:`Bearer ${t}`}});
    }catch(e){throw Error('Upload backend could not be reached. Redeploy the full Netlify project (site + functions).');}
    const ticket=await ticketR.json().catch(()=>({}));
    if(!ticketR.ok)throw Error(ticket.error||`B2 upload setup failed (${ticketR.status})`);
    if(!ticket.uploadUrl||!ticket.authorizationToken)throw Error('B2 upload setup returned an incomplete response');
    return ticket;
  }

  let lastError=null;
  for(let attempt=1;attempt<=2;attempt++){
    const ticket=await getTicket();
    if(ticket.corsUpdated) await new Promise(r=>setTimeout(r,700));
    try{
      const r=await realFetch(ticket.uploadUrl,{method:'POST',headers:{Authorization:ticket.authorizationToken,'X-Bz-File-Name':encodeURIComponent(key),'Content-Type':mime,'X-Bz-Content-Sha1':sha1},body:bytes});
      const d=await r.json().catch(()=>({}));
      if(r.ok)return {url:'b2:'+key,key,fileId:d.fileId||'',size:bytes.length};
      lastError=new Error(d.message||d.code||`B2 upload failed (${r.status})`);
      if(![401,408,429,500,503].includes(r.status))break;
    }catch(e){
      // A browser TypeError here is usually a B2 preflight/CORS failure. The ticket
      // endpoint automatically fixes the bucket CORS rule, so retry once with a fresh ticket.
      lastError=new Error(e?.message==='Failed to fetch'?'B2 browser upload was blocked. Automatic CORS repair was attempted; please retry Save once.':(e?.message||'B2 upload failed'));
    }
    if(attempt<2)await new Promise(r=>setTimeout(r,900));
  }
  throw lastError||Error('B2 upload failed');
}
async function sitePayload(){const s=await settings();const items=await allCatalog();const pub=items.filter(x=>x.status==='published').sort((a,b)=>(a.sort_order||0)-(b.sort_order||0));if(!Object.keys(s).length&&!pub.length)throw Object.assign(new Error('Cloud content not initialized'),{status:404});const group=async type=>Promise.all(pub.filter(x=>x.type===type).map(decorate));const out={settings:s,navigation:await group('navigation'),banners:await group('banners'),courses:await group('courses'),mock_tests:await group('mock_tests'),resources:await group('resources'),videos:await group('videos')};if(s.logo_url?.startsWith('b2:'))out.settings.logo_url=await signedSetting('logo_url');if(s.founder_image_url?.startsWith('b2:'))out.settings.founder_image_url=await signedSetting('founder_image_url');return out}
async function createProfile(u,{name,mobile,email,level='free'}){const id=numId();const p={id,name:name||'',mobile:mobile||'',email:email||u.email||'',status:'active',access:{level},created_at:now(),updated_at:now()};await mods.setDoc(mods.doc(db,'users',u.uid),p,{merge:true});if(mobile){const h=await sha256(normMobile(mobile));await mods.setDoc(mods.doc(db,'loginIndex',h),{email:p.email,uid:u.uid,updated_at:now()})}return p}
async function apiHandle(url,init={}){
  await ready;const U=new URL(url,location.origin),path=U.pathname,method=(init.method||'GET').toUpperCase(),body=parseBody(init);
  try{
    if(path==='/api/site')return jsonResponse(await sitePayload());
    if(path==='/api/categories'){const x=(await seedCategories()).filter(c=>c.status!=='draft');return jsonResponse(x)}
    if(path==='/api/resources'){let x=(await allCatalog()).filter(i=>i.type==='resources'&&i.status==='published');const sec=U.searchParams.get('section'),cat=U.searchParams.get('category');if(sec)x=x.filter(i=>i.meta?.section===sec);if(cat)x=x.filter(i=>i.category===cat);return jsonResponse(await Promise.all(x.sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)).map(decorate)))}
    if(path==='/api/mocks'){let x=(await allCatalog()).filter(i=>i.type==='mock_tests'&&i.status==='published');const mode=U.searchParams.get('mode'),cat=U.searchParams.get('category');if(mode)x=x.filter(i=>i.meta?.mode===mode);if(cat)x=x.filter(i=>i.category===cat);return jsonResponse(await Promise.all(x.sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)).map(decorate)))}
    if(path.startsWith('/api/item/')){const id=path.split('/').pop(),snap=await mods.getDoc(mods.doc(db,'content',String(id)));if(!snap.exists())return jsonResponse({error:'Content not found'},404);const x=await decorate(snap.data());if(!x.has_access)return jsonResponse({error:'Access required'},403);return jsonResponse(x)}
    if(path==='/api/contact'&&method==='POST'){await mods.addDoc(mods.collection(db,'messages'),{...body,created_at:now()});return jsonResponse({ok:true})}
    if(path==='/api/user/register'&&method==='POST'){const cred=await mods.createUserWithEmailAndPassword(auth,String(body.email||'').trim(),body.password||'');currentUser=cred.user;await createProfile(cred.user,body);return jsonResponse({ok:true})}
    if(path==='/api/user/login'&&method==='POST'){let ident=String(body.identifier||'').trim();let email=ident;if(!ident.includes('@')){const h=await sha256(normMobile(ident));const s=await mods.getDoc(mods.doc(db,'loginIndex',h));if(!s.exists())return jsonResponse({error:'Mobile number not found'},400);email=s.data().email}const cred=await mods.signInWithEmailAndPassword(auth,email,body.password||'');currentUser=cred.user;const p=await profile();if(p?.status==='blocked'){await mods.signOut(auth);return jsonResponse({error:'Account is blocked'},403)}return jsonResponse({ok:true})}
    if(path==='/api/user/forgot-password'&&method==='POST'){await mods.sendPasswordResetEmail(auth,String(body.email||'').trim());return jsonResponse({ok:true})}
    if(path==='/api/user/logout'&&method==='POST'){await mods.signOut(auth);currentUser=null;return jsonResponse({ok:true})}
    if(path==='/api/user/me'){if(!currentUser)return jsonResponse({error:'Login required'},401);const p=await profile();if(!p)return jsonResponse({error:'User profile not found'},404);const lib=await userLibrary(currentUser.uid);return jsonResponse({...p,library_count:lib.length})}
    if(path==='/api/user/library'){if(!currentUser)return jsonResponse({error:'Login required'},401);return jsonResponse(await userLibrary(currentUser.uid))}
    if(path==='/api/user/results'){if(!currentUser)return jsonResponse({error:'Login required'},401);const s=await mods.getDocs(mods.collection(db,'users',currentUser.uid,'results'));return jsonResponse(s.docs.map(d=>d.data()).sort((a,b)=>String(b.submitted_at).localeCompare(String(a.submitted_at))))}
    if(path==='/api/test/html-result'&&method==='POST'){if(!currentUser)return jsonResponse({error:'Login required to save HTML mock result'},401);const snap=await mods.getDoc(mods.doc(db,'content',String(body.test_id)));if(!snap.exists())return jsonResponse({error:'Mock test not found'},404);const test=snap.data();if(test.meta?.mode!=='html')return jsonResponse({error:'Not an HTML mock'},400);const p=await profile();const correct=Number(body.correct??0),incorrect=Number(body.incorrect??0),unanswered=Number(body.unanswered??0),score=Number(body.score??correct),max=Number(body.max_score??(correct+incorrect+unanswered)??0),percentage=max?Math.max(0,Math.round((score/max)*10000)/100):0;const result={id:numId(),test_id:test.id??Number(body.test_id),title:test.title??'HTML Mock Test',test_title:test.title??'HTML Mock Test',mode:'html',score,max_score:max,correct,incorrect,unanswered,percentage,time_taken:Number(body.time_taken||0),submitted_at:now(),user_name:p?.name??'',user_email:p?.email??currentUser.email??'',user_mobile:p?.mobile??''};await mods.setDoc(mods.doc(db,'users',currentUser.uid,'results',String(result.id)),result);return jsonResponse(result)}
    if(path==='/api/test/submit'&&method==='POST'){if(!currentUser)return jsonResponse({error:'Login required'},401);const snap=await mods.getDoc(mods.doc(db,'content',String(body.test_id)));if(!snap.exists())return jsonResponse({error:'Mock test not found'},404);const test=snap.data(),qs=test.meta?.questions||[],ans=body.answers||{};let correct=0,incorrect=0,unanswered=0,score=0,max=0;const review=[];qs.forEach((q,i)=>{const mark=Number(q.marks??1),neg=Number(q.negative_marks??q.negative??0),correctAnswer=(q.answer??q.correct??null);max+=mark;const a=ans[i]??ans[String(i)];const row={question:q.question??'',answer:(a===undefined||a===null||a==='')?null:a,correct_answer:correctAnswer,explanation:q.explanation??''};if(row.answer===null){unanswered++;review.push(row);return}if(correctAnswer!==null&&String(row.answer)===String(correctAnswer)){correct++;score+=mark}else{incorrect++;score-=neg}review.push(row)});const percentage=max?Math.max(0,Math.round((score/max)*10000)/100):0;const p=await profile();const result={id:numId(),test_id:test.id??Number(body.test_id),title:test.title??'Mock Test',test_title:test.title??'Mock Test',score:Math.round(score*100)/100,max_score:max,correct,incorrect,unanswered,percentage,time_taken:Number(body.time_taken||0),submitted_at:now(),user_name:p?.name??'',user_email:p?.email??currentUser.email??'',user_mobile:p?.mobile??'',review};const safeResult=JSON.parse(JSON.stringify(result,(_k,v)=>v===undefined?null:v));await mods.setDoc(mods.doc(db,'users',currentUser.uid,'results',String(safeResult.id)),safeResult);return jsonResponse(safeResult)}
    if(path==='/api/admin/login'&&method==='POST'){let email=String(body.username||'').trim();if(!email.includes('@'))email=cloudCfg.adminEmail||email;const c=await mods.signInWithEmailAndPassword(auth,email,body.password||'');currentUser=c.user;if(!admin()){await mods.signOut(auth);currentUser=null;return jsonResponse({error:'This account is not the CMS administrator'},403)}await seedCategories();return jsonResponse({ok:true})}
    if(path==='/api/admin/logout'&&method==='POST'){await mods.signOut(auth);currentUser=null;return jsonResponse({ok:true})}
    if(path==='/api/admin/me'){if(!admin())return jsonResponse({error:'Admin login required'},401);return jsonResponse({email:currentUser.email})}
    if(path==='/api/firebase/status'){return jsonResponse({configured:Boolean(cfg.apiKey&&cfg.projectId),project_id:cfg.projectId||''})}
    if(path==='/api/admin/dashboard'){requireAdmin();const items=await allContent(),users=(await mods.getDocs(mods.collection(db,'users'))).size,messages=(await mods.getDocs(mods.collection(db,'messages'))).size;const counts={items:items.length,users,messages,courses:items.filter(x=>x.type==='courses').length,mock_tests:items.filter(x=>x.type==='mock_tests').length,resources:items.filter(x=>x.type==='resources').length};return jsonResponse({counts})}
    if(path==='/api/admin/storage-status'){requireAdmin();let assignments=0,results=0;const us=await mods.getDocs(mods.collection(db,'users'));for(const u of us.docs){assignments+=(await mods.getDocs(mods.collection(db,'users',u.id,'library'))).size;results+=(await mods.getDocs(mods.collection(db,'users',u.id,'results'))).size}return jsonResponse({data_dir:'Cloud: Firebase Firestore + Backblaze B2',database:'Cloud Firestore',uploads:'Backblaze B2 private bucket',upload_files:0,upload_bytes:0,firebase_configured:true,counts:{items:(await allContent()).length,users:us.size,assignments,results}})}
    if(path==='/api/admin/categories'){requireAdmin();return jsonResponse(await seedCategories())}
    if(path==='/api/admin/category'&&method==='POST'){requireAdmin();const id=numId(),slug=String(body.slug||body.name||'category').toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')||String(id);await mods.setDoc(mods.doc(db,'categories',String(id)),{id,name:body.name||slug,slug,sort_order:Number(body.sort_order||0),status:body.status||'published',created_at:now(),updated_at:now()});return jsonResponse({id})}
    if(path.startsWith('/api/admin/category/')){requireAdmin();const id=path.split('/').pop();if(method==='PUT'){await mods.setDoc(mods.doc(db,'categories',id),{...body,id:Number(id)||body.id,updated_at:now()},{merge:true});return jsonResponse({ok:true})}if(method==='DELETE'){await mods.deleteDoc(mods.doc(db,'categories',id));return jsonResponse({ok:true})}}
    if(path==='/api/admin/items'){requireAdmin();let x=await allContent();const type=U.searchParams.get('type'),section=U.searchParams.get('section'),mode=U.searchParams.get('mode');if(type)x=x.filter(i=>i.type===type);if(section)x=x.filter(i=>i.meta?.section===section);if(mode)x=x.filter(i=>i.meta?.mode===mode);return jsonResponse(x.sort((a,b)=>(a.sort_order||0)-(b.sort_order||0)))}
    if(path==='/api/admin/item'&&method==='POST'){requireAdmin();const id=numId(),o={...body,id,created_at:now(),updated_at:now()};await mods.setDoc(mods.doc(db,'content',String(id)),o);await syncCatalog(o);return jsonResponse({id,...o})}
    if(path.startsWith('/api/admin/item/')&& !path.includes('/item-view/')){requireAdmin();const id=path.split('/').pop();if(method==='PUT'){await mods.setDoc(mods.doc(db,'content',id),{...body,updated_at:now()},{merge:true});const sn=await mods.getDoc(mods.doc(db,'content',id));if(sn.exists())await syncCatalog(sn.data());return jsonResponse({ok:true})}if(method==='DELETE'){await mods.deleteDoc(mods.doc(db,'content',id));await mods.deleteDoc(mods.doc(db,'catalog',id)).catch(()=>{});return jsonResponse({ok:true})}}
    if(path.startsWith('/api/admin/item-view/')){requireAdmin();const id=path.split('/').pop(),s=await mods.getDoc(mods.doc(db,'content',id));return s.exists()?jsonResponse(await decorate(s.data())):jsonResponse({error:'Not found'},404)}
    if(path==='/api/admin/upload'&&method==='POST'){requireAdmin();return jsonResponse(await uploadBase64(body))}
    if(path==='/api/admin/settings'){requireAdmin();if(method==='GET')return jsonResponse(await settings());await mods.setDoc(mods.doc(db,'settings','site'),{...body,updated_at:now()},{merge:true});return jsonResponse({ok:true})}
    if(path==='/api/admin/change-password'&&method==='POST'){requireAdmin();const cred=mods.EmailAuthProvider.credential(currentUser.email,body.current_password||'');await mods.reauthenticateWithCredential(currentUser,cred);await mods.updatePassword(currentUser,body.new_password||'');return jsonResponse({ok:true})}
    if(path==='/api/admin/access-items'){requireAdmin();return jsonResponse((await allContent()).filter(x=>['courses','mock_tests','resources'].includes(x.type)).sort((a,b)=>String(a.title).localeCompare(String(b.title))))}
    if(path==='/api/admin/users'){requireAdmin();const s=await mods.getDocs(mods.collection(db,'users')),out=[];for(const d of s.docs){const p={uid:d.id,...d.data()},lib=await userLibrary(d.id);p.library_details=lib;out.push(p)}return jsonResponse(out)}
    if(path==='/api/admin/user'&&method==='POST'){requireAdmin();const email=String(body.email||'').trim(),password=body.password||'';if(!email||!password)return jsonResponse({error:'Email and password are required'},400);const r=await realFetch(`https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=${encodeURIComponent(cfg.apiKey)}`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password,returnSecureToken:true})});const d=await r.json();if(!r.ok)return jsonResponse({error:d.error?.message||'Could not create user'},400);const fake={uid:d.localId,email};await createProfile(fake,{...body,email,level:body.access?.level||'free'});return jsonResponse({ok:true})}
    if(path.startsWith('/api/admin/user/')&&!path.includes('/user-library/')){requireAdmin();const id=path.split('/').pop(),u=await findUserByNumeric(id);if(!u)return jsonResponse({error:'User not found'},404);if(method==='PUT'){const patch={name:body.name??u.name,mobile:body.mobile??u.mobile,status:body.status??u.status,access:body.access??u.access,updated_at:now()};await mods.setDoc(mods.doc(db,'users',u.uid),patch,{merge:true});return jsonResponse({ok:true,note:'Auth email/password are managed through Firebase Authentication.'})}if(method==='DELETE'){await mods.deleteDoc(mods.doc(db,'users',u.uid));return jsonResponse({ok:true,note:'Firebase Authentication account remains; profile access is removed.'})}}
    if(path.startsWith('/api/admin/user-library/')){requireAdmin();const parts=path.split('/').filter(Boolean),uidNum=parts[3],action=parts[4],u=await findUserByNumeric(uidNum);if(!u)return jsonResponse({error:'User not found'},404);if(!action){return jsonResponse({assigned:await userLibrary(u.uid)})}const itemId=String(body.item_id);if(action==='grant'){await mods.setDoc(mods.doc(db,'users',u.uid,'library',itemId),{item_id:Number(itemId)||itemId,added_at:now(),granted_by:currentUser.email});return jsonResponse({ok:true})}if(action==='remove'){await mods.deleteDoc(mods.doc(db,'users',u.uid,'library',itemId));return jsonResponse({ok:true})}}
    if(path==='/api/admin/test-results'){requireAdmin();const us=await mods.getDocs(mods.collection(db,'users')),out=[];for(const u of us.docs){const s=await mods.getDocs(mods.collection(db,'users',u.id,'results'));s.forEach(d=>out.push(d.data()))}return jsonResponse(out.sort((a,b)=>String(b.submitted_at).localeCompare(String(a.submitted_at))))}
    if(path==='/api/admin/messages'){requireAdmin();const s=await mods.getDocs(mods.collection(db,'messages'));return jsonResponse(s.docs.map(d=>({id:d.id,...d.data()})).sort((a,b)=>String(b.created_at).localeCompare(String(a.created_at))))}
    return realFetch(url,init);
  }catch(e){console.error('Cloud API error',path,e);return jsonResponse({error:e.message||'Cloud request failed'},e.status||400)}
}
window.fetch=(input,init)=>{const u=typeof input==='string'?input:input?.url||'';if(u.startsWith('/api/'))return apiHandle(u,init);return realFetch(input,init)};
window.SMILE_CLOUD={ready,token,openFile:async(id,mode='view',field='file',attachmentIndex=null)=>{await ready;const t=await token();const extra=attachmentIndex===null||attachmentIndex===undefined?'':`&attachment=${encodeURIComponent(attachmentIndex)}`;const r=await realFetch(`/api/b2-file?id=${encodeURIComponent(id)}&mode=${mode==='download'?'download':'view'}&field=${field==='media'?'media':'file'}${extra}`,{headers:t?{Authorization:`Bearer ${t}`}:{}});const d=await r.json();if(!r.ok)throw Error(d.error||'File access failed');if(mode==='download')location.href=d.url;else window.open(d.url,'_blank','noopener')},downloadBackup:async()=>{requireAdmin();const data={exported_at:now(),settings:await settings(),categories:await allCategories(),content:await allContent(),users:[]};const us=await mods.getDocs(mods.collection(db,'users'));for(const u of us.docs)data.users.push({uid:u.id,...u.data(),library:await userLibrary(u.id)});const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`smile-studies-backup-${new Date().toISOString().slice(0,10)}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)}};
})();
