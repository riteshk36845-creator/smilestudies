SMILE STUDIES v4.6 — FIRESTORE + B2 FIXED (DIRECT NETLIFY)
===========================================================

PURPOSE
This build fixes the two errors seen in the cloud version:
- "Failed to fetch" while uploading PDF/HTML/TXT/images to Backblaze B2
- generic "Save failed" after an upload could not finish

WHAT CHANGED IN v4.6
1) B2 CORS is repaired automatically by the server-side Netlify function.
   You do NOT need PowerShell/B2 CLI for normal upload setup.
2) The browser still uploads the actual file directly to B2, so larger PDFs do not have to pass through a Netlify Function body limit.
3) The upload-ticket function now uses the current Netlify site origin and creates/updates the exact B2 Native API upload CORS rule required by b2_upload_file.
4) Upload retries once with a fresh B2 upload ticket if the first B2 request fails.
5) Clearer upload errors are shown instead of only "Failed to fetch".
6) Backblaze secrets are NOT embedded in the public website or source package.
7) Duplicate public copies of Netlify function source were removed from site/.

REQUIRED NETLIFY ENVIRONMENT VARIABLES
Create these in Netlify -> Project configuration -> Environment variables.
Use "Same value for all deploy contexts".

B2_APPLICATION_KEY_ID = your Backblaze key ID
B2_APPLICATION_KEY    = your Backblaze application key (mark this as secret)
B2_BUCKET_NAME        = smilestudies

Optional (the build already has safe fallbacks for these):
ADMIN_EMAIL            = your Firebase admin email
FIREBASE_WEB_API_KEY   = Firebase web API key
FIREBASE_PROJECT_ID    = smile-studies

BACKBLAZE KEY CAPABILITIES
The B2 key needs at least:
- listBuckets
- writeBuckets   (used to auto-fix the upload CORS rule)
- writeFiles
- readFiles
- shareFiles

FIREBASE
- Email/Password Authentication must be enabled.
- Publish the rules from FIRESTORE_RULES.txt in Firebase Console -> Firestore Database -> Rules.
- Do not manually create collections. The CMS creates them when data is saved.

DIRECT NETLIFY DEPLOY (NO GITHUB REQUIRED)
1) Extract this ZIP.
2) Keep the folder structure unchanged: netlify.toml, site/, netlify/functions/ must be together.
3) Deploy the COMPLETE extracted project to the existing Netlify site using the same method that deployed the previous cloud build/functions.
4) Because Environment Variables already live in Netlify, do not put B2 keys in HTML/JS files.
5) After deployment, open /admin.html, log in, and upload a small PDF first.

FIRST TEST
- Admin -> Notes (or any Resource section)
- Upload one small PDF
- Access = Free
- Status = Published
- Save
Expected: no "Failed to fetch"; the metadata saves to Firestore and the file reference saves as b2:...

VIEW / DOWNLOAD
- View asks the Netlify b2-file function for a short-lived private B2 URL and opens it in-browser where the browser supports the MIME type.
- Download uses attachment disposition.

ACCESS MODEL
- Free/Public: published content is available publicly.
- Paid/Selected: content must be granted to that student's My Library from Users & Access.
- B2 bucket can remain private.

IMPORTANT
If the B2 application key does not have writeBuckets capability, the automatic CORS repair cannot run and the upload ticket will show a clear capability error.
