'use strict';
const {json,b2Authorize,chooseBucket,bearer,firestoreGet,encPath,filenameFromKey}=require('./_shared');
exports.handler=async(event)=>{
  try{
    if(event.httpMethod!=='GET') return json(405,{error:'Method not allowed'});
    const q=event.queryStringParameters||{}, token=bearer(event); let ref='';
    if(q.settingsField){
      const s=await firestoreGet('settings/site',token);
      ref=s[q.settingsField]||'';
    }else{
      if(!q.id) return json(400,{error:'Missing content id'});
      // Firestore rules perform the actual public/assigned/admin authorization here.
      const item=await firestoreGet('content/'+String(q.id),token);
      if(q.attachment!==undefined){const idx=Number(q.attachment),atts=Array.isArray(item.meta?.attachments)?item.meta.attachments:[];ref=Number.isInteger(idx)&&idx>=0&&idx<atts.length?(atts[idx]?.url||''):'';}else ref=q.field==='media'?item.media_url:item.file_url;
    }
    if(!String(ref||'').startsWith('b2:')) return json(400,{error:'This item is not stored in B2'});
    const key=String(ref).slice(3), a=await b2Authorize(), st=a.apiInfo.storageApi, b=await chooseBucket(a);
    const u=st.apiUrl+'/b2api/v4/b2_get_download_authorization';
    const mode=q.mode==='download'?'download':'view', filename=filenameFromKey(key);
    const disposition=(mode==='download'?'attachment':'inline')+`; filename*=UTF-8''${encodeURIComponent(filename)}`;
    const r=await fetch(u,{method:'POST',headers:{Authorization:a.authorizationToken,'content-type':'application/json'},body:JSON.stringify({bucketId:b.id,fileNamePrefix:key,validDurationInSeconds:300,b2ContentDisposition:disposition})});
    const d=await r.json().catch(()=>({}));
    if(!r.ok) return json(r.status,{error:d.message||d.code||'Could not authorize file'});
    const url=`${st.downloadUrl}/file/${encodeURIComponent(b.name)}/${encPath(key)}?Authorization=${encodeURIComponent(d.authorizationToken)}&b2ContentDisposition=${encodeURIComponent(disposition)}`;
    return json(200,{url,expiresIn:300});
  }catch(e){return json(e.statusCode||500,{error:e.message||'File access failed'});}
};
