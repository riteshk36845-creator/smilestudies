'use strict';
const {b2Authorize,chooseBucket,bearer,firestoreGet,encPath}=require('./_shared');
const out=(statusCode,body,type='text/plain; charset=utf-8')=>({statusCode,headers:{'content-type':type,'cache-control':'no-store','x-content-type-options':'nosniff'},body});
exports.handler=async(event)=>{
 try{
  if(event.httpMethod!=='GET') return out(405,'Method not allowed');
  const q=event.queryStringParameters||{}; if(!q.id)return out(400,'Missing content id');
  const token=bearer(event), item=await firestoreGet('content/'+String(q.id),token);
  if(item?.meta?.mode!=='html')return out(400,'Not an HTML mock');
  const ref=String(item.file_url||''); if(!ref.startsWith('b2:'))return out(400,'HTML mock file is not stored in B2');
  const key=ref.slice(3),a=await b2Authorize(),st=a.apiInfo.storageApi,b=await chooseBucket(a);
  const ar=await fetch(st.apiUrl+'/b2api/v4/b2_get_download_authorization',{method:'POST',headers:{Authorization:a.authorizationToken,'content-type':'application/json'},body:JSON.stringify({bucketId:b.id,fileNamePrefix:key,validDurationInSeconds:120})});
  const ad=await ar.json().catch(()=>({})); if(!ar.ok)return out(502,ad.message||'Could not authorize HTML mock');
  const url=`${st.downloadUrl}/file/${encodeURIComponent(b.name)}/${encPath(key)}?Authorization=${encodeURIComponent(ad.authorizationToken)}`;
  const fr=await fetch(url); if(!fr.ok)return out(502,'Could not load HTML mock');
  let html=await fr.text();
  const bridge=`<script>(function(){function n(re,t){var m=t.match(re);return m?Number(m[1]):null}function scan(){try{var t=(document.body&&document.body.innerText)||'';var correct=n(/(?:correct|right)\\s*(?:answers?)?\\s*[:=-]\\s*(\\d+)/i,t),incorrect=n(/(?:incorrect|wrong)\\s*(?:answers?)?\\s*[:=-]\\s*(\\d+)/i,t),unanswered=n(/(?:unanswered|not\\s*answered|unattempted)\\s*[:=-]\\s*(\\d+)/i,t),m=t.match(/(?:score|marks?)\\s*[:=-]\\s*(-?\\d+(?:\\.\\d+)?)\\s*(?:\\/|out\\s+of)\\s*(\\d+(?:\\.\\d+)?)/i);if(correct!==null||incorrect!==null||m){parent.postMessage({type:'SMILE_HTML_MOCK_RESULT',correct:correct,incorrect:incorrect,unanswered:unanswered,score:m?Number(m[1]):null,max_score:m?Number(m[2]):null,text:t.slice(-5000)},'*')}}catch(e){}}new MutationObserver(function(){setTimeout(scan,250)}).observe(document.documentElement,{subtree:true,childList:true,characterData:true});window.addEventListener('message',function(e){if(e.data&&e.data.type==='SMILE_SCAN_RESULT')scan()});window.SMILE_REPORT_RESULT=function(r){parent.postMessage(Object.assign({type:'SMILE_HTML_MOCK_RESULT'},r||{}),'*')};setInterval(scan,2500)})();<\/script>`;
  html=/<\/body>/i.test(html)?html.replace(/<\/body>/i,bridge+'</body>'):html+bridge;
  return out(200,html,'text/html; charset=utf-8');
 }catch(e){return out(e.statusCode||500,e.message||'HTML mock could not be loaded');}
};
