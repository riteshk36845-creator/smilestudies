'use strict';
const {json,b2Authorize,chooseBucket,requestOrigin,requireAdmin}=require('./_shared');
exports.handler=async(event)=>{
  try{
    await requireAdmin(event);
    const a=await b2Authorize(),b=await chooseBucket(a);
    const caps=a.apiInfo.storageApi.allowed?.capabilities||[];
    const origin=requestOrigin(event);
    const cors=(b.corsRules||[]).find(r=>r?.corsRuleName==='smileStudiesUpload')||null;
    return json(200,{ok:true,bucketName:b.name,bucketId:b.id,bucketType:b.type,canUpload:caps.includes('writeFiles'),canRead:caps.includes('readFiles'),canShare:caps.includes('shareFiles'),canManageCors:caps.includes('writeBuckets'),requestOrigin:origin,uploadCors:cors});
  }
  catch(e){return json(e.statusCode||500,{ok:false,error:e.message});}
};
