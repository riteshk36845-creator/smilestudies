'use strict';
const C = require('./_config');
const b64 = s => Buffer.from(s,'utf8').toString('base64');
const json = (statusCode, body, extra={}) => ({statusCode,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store',...extra},body:JSON.stringify(body)});

function assertB2Config(){
  const missing=[];
  if(!C.B2_KEY_ID) missing.push('B2_APPLICATION_KEY_ID');
  if(!C.B2_APPLICATION_KEY) missing.push('B2_APPLICATION_KEY');
  if(!C.PREFERRED_BUCKET_NAME) missing.push('B2_BUCKET_NAME');
  if(missing.length) throw Object.assign(new Error('Missing environment variable(s): '+missing.join(', ')),{statusCode:500});
}

async function b2Authorize(){
  assertB2Config();
  const r=await fetch('https://api.backblazeb2.com/b2api/v4/b2_authorize_account',{headers:{Authorization:'Basic '+b64(C.B2_KEY_ID+':'+C.B2_APPLICATION_KEY)}});
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw Object.assign(new Error('Backblaze authorization failed: '+(d.message||d.code||r.status)),{statusCode:502});
  return d;
}

async function listBuckets(auth){
  const st=auth?.apiInfo?.storageApi||{};
  const u=new URL(st.apiUrl+'/b2api/v4/b2_list_buckets');
  u.searchParams.set('accountId',auth.accountId);
  const r=await fetch(u,{headers:{Authorization:auth.authorizationToken}});
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw Object.assign(new Error('Could not list B2 buckets: '+(d.message||d.code||r.status)),{statusCode:502});
  return d.buckets||[];
}

async function chooseBucket(auth){
  const st=auth?.apiInfo?.storageApi||{};
  const allowed=st.allowed||{};
  const allowedBuckets=Array.isArray(allowed.buckets)?allowed.buckets:[];
  const caps=new Set(allowed.capabilities||[]);
  const pref=String(C.PREFERRED_BUCKET_NAME||'').toLowerCase();

  // Prefer a full bucket record so we can inspect/update CORS automatically.
  if(caps.has('listBuckets')){
    const list=await listBuckets(auth);
    const hit=list.find(b=>String(b.bucketName||'').toLowerCase()===pref)
      || list.find(b=>/smile/i.test(String(b.bucketName||'')))
      || (list.length===1?list[0]:null);
    if(!hit) throw Object.assign(new Error(`B2 bucket "${C.PREFERRED_BUCKET_NAME}" was not found. Check B2_BUCKET_NAME.`),{statusCode:500});
    return {id:hit.bucketId,name:hit.bucketName,type:hit.bucketType||'allPrivate',corsRules:Array.isArray(hit.corsRules)?hit.corsRules:[]};
  }

  if(allowedBuckets.length===1) return {id:allowedBuckets[0].id,name:allowedBuckets[0].name,type:'allPrivate',corsRules:[]};
  if(allowedBuckets.length){
    const hit=allowedBuckets.find(b=>String(b.name||'').toLowerCase()===pref)||allowedBuckets.find(b=>/smile/i.test(String(b.name||'')));
    if(hit) return {id:hit.id,name:hit.name,type:'allPrivate',corsRules:[]};
  }
  throw Object.assign(new Error('The B2 key cannot resolve the website bucket. Give it listBuckets access or restrict it to the Smile Studies bucket.'),{statusCode:500});
}

function requestOrigin(event){
  const h=event.headers||{};
  const direct=String(h.origin||h.Origin||'').trim();
  if(direct && /^https?:\/\//i.test(direct)) return direct.replace(/\/$/,'');
  const ref=String(h.referer||h.referrer||'').trim();
  if(ref){try{return new URL(ref).origin}catch{}}
  const host=String(h['x-forwarded-host']||h.host||'').trim();
  const proto=String(h['x-forwarded-proto']||'https').split(',')[0].trim()||'https';
  if(host) return `${proto}://${host}`.replace(/\/$/,'');
  return '';
}

function sameRule(a,b){
  const norm=x=>JSON.stringify({
    corsRuleName:x?.corsRuleName||'',
    allowedOrigins:[...(x?.allowedOrigins||[])].sort(),
    allowedHeaders:[...(x?.allowedHeaders||[])].map(v=>String(v).toLowerCase()).sort(),
    allowedOperations:[...(x?.allowedOperations||[])].sort(),
    exposeHeaders:[...(x?.exposeHeaders||[])].map(v=>String(v).toLowerCase()).sort(),
    maxAgeSeconds:Number(x?.maxAgeSeconds||0)
  });
  return norm(a)===norm(b);
}

async function ensureUploadCors(auth,bucket,event){
  const st=auth?.apiInfo?.storageApi||{};
  const caps=new Set(st.allowed?.capabilities||[]);
  const origin=requestOrigin(event);
  if(!origin) return {ok:false,updated:false,origin:'',warning:'Could not determine website origin for B2 CORS.'};

  const rule={
    corsRuleName:'smileStudiesUpload',
    allowedOrigins:[origin],
    // Wildcard headers are limited to this exact website origin + upload operation.
    // This avoids browser preflight failures when Content-Type/header casing varies.
    allowedHeaders:['*'],
    allowedOperations:['b2_upload_file'],
    exposeHeaders:['x-bz-file-id','x-bz-file-name','x-bz-content-sha1'],
    maxAgeSeconds:3600
  };
  const existing=Array.isArray(bucket.corsRules)?bucket.corsRules:[];
  const old=existing.find(r=>r?.corsRuleName==='smileStudiesUpload');
  if(old && sameRule(old,rule)) return {ok:true,updated:false,origin};

  if(!caps.has('writeBuckets')){
    throw Object.assign(new Error('B2 CORS needs one-time setup, but this application key is missing writeBuckets capability.'),{statusCode:500});
  }

  const corsRules=[...existing.filter(r=>r?.corsRuleName!=='smileStudiesUpload'),rule];
  const r=await fetch(st.apiUrl+'/b2api/v4/b2_update_bucket',{
    method:'POST',
    headers:{Authorization:auth.authorizationToken,'content-type':'application/json'},
    body:JSON.stringify({accountId:auth.accountId,bucketId:bucket.id,corsRules})
  });
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw Object.assign(new Error('Could not configure B2 browser upload CORS: '+(d.message||d.code||r.status)),{statusCode:502});
  bucket.corsRules=Array.isArray(d.corsRules)?d.corsRules:corsRules;
  return {ok:true,updated:true,origin};
}

function bearer(event){
  const h=event.headers?.authorization||event.headers?.Authorization||'';
  return /^Bearer\s+/i.test(h)?h.replace(/^Bearer\s+/i,'').trim():'';
}
async function verifyFirebaseIdToken(idToken){
  if(!idToken) return null;
  if(!C.FIREBASE_WEB_API_KEY) throw Object.assign(new Error('FIREBASE_WEB_API_KEY is not configured'),{statusCode:500});
  const r=await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${encodeURIComponent(C.FIREBASE_WEB_API_KEY)}`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({idToken})});
  const d=await r.json().catch(()=>({}));
  if(!r.ok||!d.users?.[0]) return null;
  return d.users[0];
}
async function requireAdmin(event){
  const u=await verifyFirebaseIdToken(bearer(event));
  if(!u||String(u.email||'').toLowerCase()!==C.ADMIN_EMAIL.toLowerCase()) throw Object.assign(new Error('Admin login required'),{statusCode:401});
  return u;
}

function decodeFirestore(v){
  if(!v||typeof v!=='object') return null;
  if('stringValue' in v) return v.stringValue;
  if('integerValue' in v) return Number(v.integerValue);
  if('doubleValue' in v) return Number(v.doubleValue);
  if('booleanValue' in v) return !!v.booleanValue;
  if('nullValue' in v) return null;
  if('timestampValue' in v) return v.timestampValue;
  if('arrayValue' in v) return (v.arrayValue.values||[]).map(decodeFirestore);
  if('mapValue' in v){ const o={}; for(const [k,x] of Object.entries(v.mapValue.fields||{})) o[k]=decodeFirestore(x); return o; }
  return null;
}
async function firestoreGet(path,idToken=''){
  const url=`https://firestore.googleapis.com/v1/projects/${encodeURIComponent(C.FIREBASE_PROJECT_ID)}/databases/(default)/documents/${path.split('/').map(encodeURIComponent).join('/')}`;
  const headers={}; if(idToken) headers.Authorization='Bearer '+idToken;
  const r=await fetch(url,{headers});
  const d=await r.json().catch(()=>({}));
  if(!r.ok) throw Object.assign(new Error(d.error?.message||'Access denied'),{statusCode:r.status===403?403:r.status});
  const o={}; for(const [k,v] of Object.entries(d.fields||{})) o[k]=decodeFirestore(v); return o;
}

function encPath(key){return String(key).split('/').map(encodeURIComponent).join('/')}
function filenameFromKey(key){const x=String(key).split('/').pop()||'file'; return x.replace(/^\d+-[0-9a-f-]+-/i,'')}
module.exports={C,json,assertB2Config,b2Authorize,listBuckets,chooseBucket,requestOrigin,ensureUploadCors,bearer,verifyFirebaseIdToken,requireAdmin,firestoreGet,encPath,filenameFromKey};
