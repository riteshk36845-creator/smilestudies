'use strict';
const {json,b2Authorize,chooseBucket,ensureUploadCors,requireAdmin}=require('./_shared');
exports.handler=async(event)=>{
  try{
    if(event.httpMethod!=='POST') return json(405,{error:'Method not allowed'});
    await requireAdmin(event);
    const a=await b2Authorize();
    const st=a.apiInfo.storageApi;
    const b=await chooseBucket(a);
    const cors=await ensureUploadCors(a,b,event);

    const u=new URL(st.apiUrl+'/b2api/v4/b2_get_upload_url');
    u.searchParams.set('bucketId',b.id);
    const r=await fetch(u,{headers:{Authorization:a.authorizationToken}});
    const d=await r.json().catch(()=>({}));
    if(!r.ok) return json(502,{error:d.message||d.code||'Could not get B2 upload URL'});
    return json(200,{
      uploadUrl:d.uploadUrl,
      authorizationToken:d.authorizationToken,
      bucketId:b.id,
      bucketName:b.name,
      corsReady:Boolean(cors.ok),
      corsUpdated:Boolean(cors.updated),
      allowedOrigin:cors.origin||''
    });
  }catch(e){
    console.error('b2-upload-ticket',e);
    return json(e.statusCode||500,{error:e.message||'Upload ticket failed'});
  }
};
