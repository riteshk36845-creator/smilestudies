'use strict';
const env = process.env || {};
module.exports = {
  // Keep B2 secrets ONLY in Netlify Environment Variables.
  // Supports both the current variable name and the older legacy name.
  B2_KEY_ID: String(env.B2_APPLICATION_KEY_ID || env.B2_KEY_ID || '').trim(),
  B2_APPLICATION_KEY: String(env.B2_APPLICATION_KEY || '').trim(),
  PREFERRED_BUCKET_NAME: String(env.B2_BUCKET_NAME || 'smilestudies').trim(),

  // Firebase web API key/project id are public web configuration values, not service-account secrets.
  FIREBASE_WEB_API_KEY: String(env.FIREBASE_WEB_API_KEY || 'AIzaSyA_PqbAmxLz8t6K4KrOaydStrHrodLtTzs').trim(),
  FIREBASE_PROJECT_ID: String(env.FIREBASE_PROJECT_ID || 'smile-studies').trim(),
  ADMIN_EMAIL: String(env.ADMIN_EMAIL || 'kritesh2663@gmail.com').trim()
};
