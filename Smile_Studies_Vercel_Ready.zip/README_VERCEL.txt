SMILE STUDIES v5.0 — VERCEL DEPLOY PACKAGE
===========================================

PROJECT LAYOUT
- site/                 Static website files (Vercel output directory)
- api/                  Vercel serverless-function adapters
- netlify/functions/    Shared existing Backblaze B2/Firebase server logic
- vercel.json           Vercel routing and response headers
- FIRESTORE_RULES.txt   Firestore rules reference

DEPLOY TO VERCEL
1. Extract this ZIP.
2. In Vercel, choose Add New -> Project -> Import the extracted project through a Git repository.
   (Recommended: upload/push the complete extracted folder to a private GitHub repository, then import it.)
3. In Project Settings -> Build and Deployment:
   - Framework Preset: Other
   - Build Command: leave blank
   - Output Directory: site
   - Install Command: leave blank
4. In Project Settings -> Environment Variables, add the variables below for Production (and Preview if needed).
5. Deploy, then test the site and the /api endpoints.

REQUIRED ENVIRONMENT VARIABLES
- B2_APPLICATION_KEY_ID = Backblaze B2 application key ID
- B2_APPLICATION_KEY = Backblaze B2 application key (SECRET)
- B2_BUCKET_NAME = smilestudies

OPTIONAL ENVIRONMENT VARIABLES
- ADMIN_EMAIL = Firebase admin email used by this site
- FIREBASE_WEB_API_KEY = Firebase web API key (public client config; defaults to the current project key)
- FIREBASE_PROJECT_ID = smile-studies

IMPORTANT SECURITY NOTES
- Never put B2_APPLICATION_KEY in HTML, JavaScript, or any VITE_/NEXT_PUBLIC_ variable.
- The Firebase web API key is a browser-side identifier, not a server secret. Restrict it in Google Cloud if appropriate.
- Ensure Firebase Email/Password Authentication is enabled.
- Publish FIRESTORE_RULES.txt in Firebase Console -> Firestore Database -> Rules.
- The B2 key needs the capabilities required by your workflow: listBuckets, writeBuckets (for automatic upload CORS setup), writeFiles, readFiles, and shareFiles.
- Vercel Functions have execution/body limits. This site uploads the file directly from the browser to B2 using an upload ticket, rather than sending the file body through a function.

ROUTES
- /admin -> /admin.html
- /login and /library -> /user.html
- /resources -> /resource-center.html
- /mocks -> /mocks.html
- /api/b2-file, /api/b2-html-content, /api/b2-status, /api/b2-upload-ticket are Vercel serverless endpoints.

POST-DEPLOY TESTS
1. Open the homepage and check browser console for 404/JavaScript errors.
2. Test /login and /library routes.
3. Sign in as the configured admin and open /admin.html.
4. In Admin -> Notes or a Resource section, upload a small PDF first.
5. Verify save, public view/download, and HTML mock result reporting.
6. If upload fails, check Vercel -> Project -> Functions/Logs and verify the B2 environment variables and key capabilities.

This package adapts the existing Netlify function handlers for Vercel and changes browser API paths to /api/*. It cannot verify live Firebase/B2 credentials or deployed-project settings from the ZIP alone.
