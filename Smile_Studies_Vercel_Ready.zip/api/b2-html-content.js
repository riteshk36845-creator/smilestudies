'use strict';
const handler = require('../netlify/functions/b2-html-content').handler;

module.exports = async function (req, res) {
  const headers = Object.fromEntries(Object.entries(req.headers || {}).map(([k, v]) => [k.toLowerCase(), Array.isArray(v) ? v.join(', ') : String(v ?? '')]));
  const queryStringParameters = Object.fromEntries(Object.entries(req.query || {}).map(([k, v]) => [k, Array.isArray(v) ? v[0] : String(v ?? '')]));
  let body = req.body;
  if (body && typeof body !== 'string' && !Buffer.isBuffer(body)) {
    try { body = JSON.stringify(body); } catch { body = ''; }
  }
  const event = {
    httpMethod: req.method,
    headers,
    queryStringParameters,
    body: body == null ? null : Buffer.isBuffer(body) ? body.toString('utf8') : String(body),
    rawUrl: `${headers['x-forwarded-proto'] || 'https'}://${headers['x-forwarded-host'] || headers.host || ''}${req.url || ''}`
  };
  try {
    const result = await handler(event);
    const status = result?.statusCode || 200;
    for (const [key, value] of Object.entries(result?.headers || {})) res.setHeader(key, value);
    if (result?.isBase64Encoded) {
      res.status(status).send(Buffer.from(result.body || '', 'base64'));
    } else {
      res.status(status).send(result?.body ?? '');
    }
  } catch (error) {
    console.error('b2-html-content adapter error:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
};
